#v1
name='Azamat';
print('Name:',name,type(name));
age=31;
print('Age:',age,type(age));
new_age=age+int('1')
print('New age:',int(new_age),type(new_age));
is_student=True;
print('Is_student:',is_student,type(is_student));
#v2
name='Azamat';
print('Name:',name,type(name));
age=31;
print('Age:',age,type(age));
age=age+int('1')
print('New age:',int(age),type(age));
is_student=True;
print('Is_student:',is_student,type(is_student));